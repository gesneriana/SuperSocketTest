package SuperSocket;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

/**
 * Created by 结城明日奈 on 2017/5/1.
 */
public class ReadMsg extends Thread {

	@Override
	public void run() {
		super.run();
		try {
			if (SendMsg.socket != null) {
				Socket socket = SendMsg.socket; 
				while (true && socket.isConnected()) {
					InputStream inputStream = socket.getInputStream();
					if (inputStream.available() > 0) {
						DataInputStream dis = new DataInputStream(inputStream);
						String s = dis.readLine();
						// Log.d("服务器响应:", res);
						System.out.println("服务器响应:" + Base64Util.decode(s));
					}
					sleep(1000 * 1);
				}
			}
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}