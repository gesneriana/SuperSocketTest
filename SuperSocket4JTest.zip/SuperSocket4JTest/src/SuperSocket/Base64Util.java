package SuperSocket;
import org.apache.commons.codec.binary.Base64;

/**
 * 专门为了传输中文乱码的解决方案
 * 
 * @author Pingfeng_Zhang
 *
 */
public class Base64Util {

	/**
	 * 编码
	 * 
	 * @param string
	 *            , 默认为UTF-8
	 * @return
	 */
	public static String encode(String string) {
		try {
			return Base64.encodeBase64String(string.getBytes("utf-8"));
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * 以指定的字符编码转换为base64
	 * 
	 * @param string
	 * @param enc
	 * @return
	 */
	public String encode(String string, String enc) {
		try {
			return Base64.encodeBase64String(string.getBytes(enc));
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * 解码
	 * 
	 * @param string, base64字符串
	 * @return
	 */
	public static String decode(String string) {
		try {
			byte[] asBytes = Base64.decodeBase64(string);
			return new String(asBytes, "utf-8");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return "";
		}
	}
}
