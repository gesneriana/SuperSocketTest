package SuperSocket;

import java.io.IOException;
import java.util.Scanner;

public class Test {

	private static SendMsg sm;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		byte[] b = "咸鱼".getBytes();
		for (int i = 0; i < b.length; i++) {
			int temp = b[i] & 0xFF;
			System.out.println("b:" + temp + "\t");
		}
		*/
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.print("请输入字符串:");
			String s = sc.nextLine();

			if ("exit".equals(s)) {
				if (SendMsg.socket != null && SendMsg.socket.isConnected()) {
					try {
						SendMsg.socket.close();
						SendMsg.socket=null;
					} catch (IOException ex) {
						System.err.println("ioe error msg:" + ex.getMessage());
						ex.printStackTrace();
					}
				}
				sc.close();
			}else {
				sm = new SendMsg();
				sm.msg = s;
				sm.start();
			}
		}
	}

}