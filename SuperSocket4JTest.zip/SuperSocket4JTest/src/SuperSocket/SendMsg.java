package SuperSocket;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Created by 结城明日奈 on 2017/5/1.
 */
public class SendMsg extends Thread {

	private static String IpAddress = "127.0.0.1";
	private static int Port = 1994;
	public static Socket socket = null;

	public String msg;

	/**
	 * 开启一个线程发送消息到服务器
	 */
	@Override
	public void run() {
		super.run();
		try {
			if (socket != null && !socket.isConnected()) {
				socket.close();
				socket = null;
			}
			if (socket == null) {
				socket = new Socket(IpAddress, Port);
				socket.setTcpNoDelay(true);
				socket.setKeepAlive(true);
				// 第一次创建socket时候,同时创建 读取线程
				ReadMsg rm = new ReadMsg();
				rm.start();
			}

			// 获取客户端的输出流,发送数据到服务器
			PrintWriter out = new PrintWriter(new BufferedWriter(
					new OutputStreamWriter(socket.getOutputStream())), true);
			if (msg.indexOf("3") >= 0) {
				String[] temp = msg.split(" ");
				msg = temp[0] + " " + Base64Util.encode(temp[1]) + "\r\n";
				out.print(msg);
			} else {
				out.print(msg + "\r\n");
			}
			out.flush();

		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		this.interrupt();
	}
}